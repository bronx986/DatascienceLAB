class Classe_Davide:
    def __init__(self, dataset):
        self.dataset = dataset
    
    def verifica_nan (self):
        """
        Il modulo verifica la presenza di valori NaN nelle colonne del dataset, ritorna una lista contenente i 
        nomi delle colonne che contengono nan o una lista vuota se nessun nan è presente.
        Come argomento accetta la sola tabella da verificare.
        """
        nan_columns = self.dataset.columns[self.dataset.isna().any()].tolist()
        if not nan_columns:
            print("Non ci sono valori NaN nel dataset in input.")
        else:
            print("Sono presenti valori nan:")
            for col in nan_columns:
                print(col)
        return nan_columns
    
    def split_dataset(self):
        """
        Il modulo serve a separa le variabili numeriche da quelle alfanumeriche in una tabella.
        La funzione ritorna in output 2 liste.
        """
        import numpy as np
        num_cols = self.dataset.select_dtypes(include=[np.number]).columns.tolist()
        alpha_cols = self.dataset.select_dtypes(include=['object', 'category']).columns.tolist()
        print("La prima lista contiene le variabili numeriche, la seconda le categoriche.")
        return num_cols, alpha_cols
